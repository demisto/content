{\rtf1\ansi\ansicpg1252\cocoartf1671\cocoasubrtf100
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 ## Overview\
---\
This integration was integrated and tested with version xx of Google Resource Manager\
## Google Resource Manager Playbook\
---\
## Use cases\
- Create a new Google Cloud Project\
- Delete an existing Google Cloud Project\
- Get details of a Google Cloud Project\
- List all the Google Cloud Projects in an Organization\
- Update attributes of an existing Google Cloud Project \
- Get details on a Google Cloud Organization\
- Search the Google Cloud Organizations visible to the user\
---\
\
## Configure Google Resource Manager on Demisto\
---\
\
Please go to http://love-datou.com:8000 to acquire the access_token\
\
**Integration Guide**\
\
*Getting access token for Authentication* \
1. On your Google Cloud console, go to left sliding menu, **API & Services** > **Credentials** > **OAuth Consent Screen**. Enter the following details on this page:\
- Application Type: Public\
- Application Name: Custom name provided by the creator\
- Application Logo: [Logo Download] (link)\
- Support email: Email of the creator\
- Authorized Domain: [Demisto] (link)\
- Authorized Homepage link: [Demisto] (link)\
- Application Privacy Policy link: [Demisto Privacy Policy] (https://www.demisto.com/privacy/)\
2. Next, go to **API & Services** > **Credentials** > **Credentials**. Using **Create Credentials** choose **OAuth client ID** and **Web application** under it. Enter the following details on this page:\
- Name: Custom name provided by the creator\
- Authorized Javascript Origin: [Demisto] (link)\
- Authorized Redirect Origin: [Demisto] (link)\
3. The **Client ID** and **Client Secret** mentioned in the OAuth 2.0 Client ID are to be used in the next step.\
4. Now, go to <Demisto.com> and enter the **Client ID** and **Client Secret** and click <button>\
5. The **access_token** received here, is the token to be used for integrating the API in Demisto in the following steps.\
\
*Integrating Resource Manager on Demisto*\
1. Go to settings\
2. Search for **Google Compute Instance**\
3. Click on **Add Instance**, this should slide in a pop-up\
4. Enter the following details here:\
*  Name of the instance: This is a custom name provided by the creator\
*  Access Token: This is the access token received in the previous steps\
5. Test the integration and click *Done* if success\
\
## Commands\
---\
You can execute these commands from the Demisto CLI, as part of an automation, or in a playbook.\
After you successfully execute a command, a DBot message appears in the War Room with the command details.\
1. gresource-get-project\
2. gresource-list-projects\
3. gresource-create-project\
4. gresource-delete-project\
5. gresource-update-project\
6. gresource-get-organization\
7. gresource-search-organization\
\
### gresource-get-project\
---\
Retrieves the Project identified by the specified projectId. The caller must have read permissions for this Project\
##### Base Command\
`gresource-get-project`\
##### Input\
| **Argument Name** | **Description** | **Required** |\
| --- | --- | --- |\
| projectId | The Project ID  (for example, my-project-123) | True | \
##### Context Output\
| **Path** | **Type** | **Description** |\
| --- | --- | --- |\
| Gcp.Project.Id | string | The unique, user-assigned ID of the Project.  | \
| Gcp.Project.Name | string | The user-assigned display name of the Project | \
| Gcp.Project.Labels | unknown | The labels associated with this Project | \
| Gcp.Project.Parent | unknown | An optional reference to a parent resource. Supported parent types include "organization" and "folder". | \
| Gcp.Project.LifecycleState | unknown | The Project lifecycle state | \
##### Command Example\
`!gresource-get-project projectId=tokyo-rain-123`\
\
##### Human Readable Output\
\
### Get details of a Google Cloud Project\
| **Feature** | **Feature Detail** |\
| ----------- | ----------- |\
| Project Name | My First Project |\
| Project Creation Time	| 2018-09-24T04:33:03.744Z |\
| Project Lifecycles State | ACTIVE |\
| Project Labels | N/A |\
| Project Parent | type: organization id: 555550001144 |\
| Project Id | tokyo-rain-123\
\
### gresource-list-projects\
---\
Lists Projects that are visible to the user and satisfy the specified filter. This method returns Projects in an unspecified orde\
##### Base Command\
`gresource-list-projects`\
##### Input\
| **Argument Name** | **Description** | **Required** |\
| --- | --- | --- |\
| filter | An expression for filtering the results of the request. Filter rules are case insensitive. | False | \
##### Context Output\
| **Path** | **Type** | **Description** |\
| --- | --- | --- |\
| Gcp.Project.Id | unknown | The unique, user-assigned ID of the Project | \
| Gcp.Project.Name | unknown | The user-assigned display name of the Project | \
| Gcp.Project.Label | unknown | The labels associated with this Project | \
| Gcp.Project.Parent | unknown | An optional reference to a parent Resource | \
| Gcp.Project.Lifecycle | unknown | The Project lifecycle state | \
##### Command Example\
`!gresource-list-projects` \
\
##### Human Readable Output\
### List of all the Google Cloud Projects\
| Project Name | Project Creation Time | Project Lifecycle State | Project ID | Project Parent |\
| --- | --- | --- | --- |--- |\
| test-project | 2018-10-29T13:53:35.684Z | ACTIVE | test-project-29041992 | type: organization id: 902152751144 |\
| My Project 73075 | 2018-10-26T22:18:48.902Z | ACTIVE | gothic-concept-2019222 | type: organization id: 90215275555 |\
| My Second Project | 2018-10-24T22:29:56.970Z | ACTIVE | my-second-project-39222 | type: organization id: 90215275555 |\
| My Project 77835 | 2018-10-24T22:29:42.268Z | ACTIVE | learned-helper-223422 | type: organization id: 90215275555 |\
| My First Project | 2018-09-24T04:33:03.744Z | ACTIVE | sunlit-context-593404 | type: organization id: 90215275555 |\
\
### gresource-create-project\
---\
Create a project resource \
##### Base Command\
`gresource-create-project`\
##### Input\
| **Argument Name** | **Description** | **Required** |\
| --- | --- | --- |\
| projectName | The user-assigned display name of the Project. For example, My Project | True | \
| lables | The labels associated with this Project. For example, "environment" : "dev" | False | \
| projectId | The unique, user-assigned ID of the Project. For example, tokyo-rain-123 | True | \
| parentType | Required field representing the resource type this id is for. | True | \
| parentId | Parent id, that can be found in Google Console URL under 'IAM & Admin' > 'Identity & Organization' | True | \
##### Context Output\
There is no context output for this command.\
\
##### Command Example\
`!gresource-create-project parentId=902152751144 parentType=organization projectId=sunlit-context-212234 projectName=new-test-project`\
\
##### Human Readable Output\
### Create a new Google Cloud Project\
| **Argument Name** | **Argument Description** |\
| --- | --- | \
| Server assignned name	| operations/cp.6792289187908090362 |\
\
### gresource-delete-project\
---\
Marks the Project identified by the specified projectId (for example, my-project-123) for deletion\
##### Base Command\
`gresource-delete-project`\
##### Input\
| **Argument Name** | **Description** | **Required** |\
| --- | --- | --- |\
| projectId | The Project ID (for example, foo-bar-123) | True | \
##### Context Output\
| **Path** | **Type** | **Description** |\
| --- | --- | --- |\
| Gcp.Project.Id | string | The Project ID (for example, foo-bar-123) | \
##### Command Example\
`!gresource-delete-project projectId=test-project-29041992`\
\
##### Human Readable Output\
### Marking the request Google Cloud Project for deletion\
| **Argument Name** | **Argument Description** |\
| --- | --- |\
| Project ID | test-project-29041992 |\
\
### gresource-update-project\
---\
Updates the attributes of the Project identified by the specified projectId (for example, my-project-123)\
##### Base Command\
`gresource-update-project`\
##### Input\
| **Argument Name** | **Description** | **Required** |\
| --- | --- | --- |\
| projectId | The project ID (for example, my-project-123) | True | \
| projectName | The user-assigned display name of the Project. For example, My Project | False | \
| parentType | Required field representing the resource type this id is for. At present, the valid types are: "organization" and "folder" | True | \
| parentId | Parent id, that can be found in Google Console URL under 'IAM & Admin' > 'Identity & Organization' | True | \
##### Context Output\
| **Path** | **Type** | **Description** |\
| --- | --- | --- |\
| Gcp.Project.Id | unknown | The unique, user-assigned ID of the Project.  | \
| Gcp.Project.Name | unknown | The user-assigned display name of the Project.  | \
| Gcp.Project.Labels | unknown | The labels associated with this Project.  | \
| Gcp.Project.LifecycleState | unknown | Project lifecycle states. | \
| Gcp.Project.Parent | unknown | An optional reference to a parent Resource. | \
##### Command Example\
`!gresource-update-project parentId=902152751144 parentType=organization projectId=my-second-project-220422 label_key=user_name label_value=dm projectName=new-updated-name`\
\
##### Human Readable Output\
### Updated Google Cloud Project\
| Project Parent | type: organization id: 902152751144 |\
| Project Name | new-update-name |\
| Project Creation Time	| 2018-10-24T22:29:56.970Z |\
| Project Labels | [\{"user_name": "dm"\}] |\
| Project Lifecycle State | ACTIVE |\
| Project Id | my-second-project-220422 |\
\
### gresource-get-organization\
---\
Fetches an Organization resource identified by the specified resource name\
##### Base Command\
`gresource-get-organization`\
##### Input\
| **Argument Name** | **Description** | **Required** |\
| --- | --- | --- |\
| organizationId | The resource name of the Organization to fetch, e.g. "organizations/1234". Add organization id after 'organizations/' | True | \
##### Context Output\
| **Path** | **Type** | **Description** |\
| --- | --- | --- |\
| Gcp.Org.Name | unknown | The resource name of the Organization to fetch, e.g. "organizations/1234" | \
##### Command Example\
`!gresource-get-organization organizationId=organizations/955552755544 `\
##### Human Readable Output\
### Get details of a Google Cloud Organization\
| **Argument Name** | **Description** |\
| --- | --- |\
| Organization Name | organizations/902152751144 |\
| Organization Lifecycle State | ACTIVE |\
| Organization Creation Time | 2017-01-18T07:28:06.260Z |\
| Organization Owner | directoryCustomerId: C019tg2g7 |\
\
### gresource-search-organization\
---\
Searches Organization resources that are visible to the user and satisfy the specified filter.\
##### Base Command\
`gresource-search-organization`\
##### Input\
| **Argument Name** | **Description** | **Required** |\
| --- | --- | --- |\
| filter | An optional query string used to filter the Organizations to return in the response. Filter rules are case-insensitive. Organizations may be filtered by owner.directoryCustomerId (For eg. owner.directorycustomerid:123456789) or by domain (for eg. domain:google.com), where the domain is a G Suite domain.  | False | \
##### Context Output\
| **Path** | **Type** | **Description** |\
| --- | --- | --- |\
| Gcp.Org.Name | string | The resource name of the Organization to fetch, e.g. "organizations/1234" | \
| Gcp.Org.DisplayName | string | A human-readable string that refers to the Organization in the GCP Console UI.  | \
| Gcp.Org.Owner | unknown | The owner of this Organization | \
| Gcp.Org.CreationTime | string | Timestamp when the Organization was created. | \
| Gcp.Org.LifecycleState | unknown | The organization's current lifecycle state. Assigned by the server. |\
 \
##### Command Example\
`!gresource-search-organization`\
\
##### Human Readable Output\
### Search for a Google Cloud Organization\
| **Argument Name** | **Description** |\
| --- | --- |\
| Organization Name | organizations/902152751144 |\
| Organization Lifecycle State | ACTIVE |\
| Organization Display Name | west.cmu.edu |\
| Organization Owner | directoryCustomerId: C019tg2g7 |\
| Organization Creation Time | 2017-01-18T07:28:06.260Z |\
}