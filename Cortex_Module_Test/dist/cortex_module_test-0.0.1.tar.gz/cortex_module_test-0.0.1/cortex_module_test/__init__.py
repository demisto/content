def hello():
    return "Hello from cortex module test!"