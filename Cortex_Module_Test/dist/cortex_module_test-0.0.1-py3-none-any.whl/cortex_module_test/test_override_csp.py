
def arg_to_number(arg, arg_name=None, required=False):
    print("In arg_to_number from cortex module test!") # noqa: T201
    return arg
    