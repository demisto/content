### Query Timeseries Points 
