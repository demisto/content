Simple, manual process to modify external dynamic lists (EDLs) in Cortex XSOAR. This pack may help replace an existing manual process for updating firewall allowlists and blocklists, so analysts may make these changes directly in Cortex XSOAR. You just need to simply paste in a list of indicators to add or remove them from the EDL. 

Note: This pack does not perform indicator type validation at this time. Indicators will be added to the EDL exactly as entered.

