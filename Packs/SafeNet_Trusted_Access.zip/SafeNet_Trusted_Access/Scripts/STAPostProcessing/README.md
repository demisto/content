Post processing script to remove the user from the Unusual Activity Group on Close Form.

## Script Data
---

| **Name** | **Description** |
| --- | --- |
| Script Type | python3 |
| Tags | post-processing, field-change-triggered |
| Cortex XSOAR Version | 6.0.0 |

## Inputs
---
There are no inputs for this script.

## Outputs
---
There are no outputs for this script.
