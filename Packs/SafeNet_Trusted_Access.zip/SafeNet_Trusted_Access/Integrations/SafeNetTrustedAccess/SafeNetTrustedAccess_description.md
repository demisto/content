#### SafeNet Trusted Access
- For information about the configuration steps, visit our [Help Documentation](https://thalesdocs.com/sta/Content/STA/SecurityInt/CortexXSOAR_PaloAltoNetworks.htm).
