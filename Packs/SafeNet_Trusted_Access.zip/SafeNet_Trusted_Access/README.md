SafeNet Trusted Access prevents data breaches, helps with compliance with regulations, and supports migration to the cloud in a simple and secure fashion.

## This pack enables you to:

-	Receive and process SafeNet Trusted Access alerts that indicate security risks to end user accounts.
-	Apply security remediation actions on SafeNet Trusted Access.

For information about the configuration steps, visit our [Help Documentation](https://thalesdocs.com/sta/Content/STA/SecurityInt/CortexXSOAR_PaloAltoNetworks.htm).